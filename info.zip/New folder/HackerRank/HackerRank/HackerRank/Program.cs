﻿using System;
using System.Collections.Generic;

namespace HackerRank
{
    class SockMerchant
    {
        private int _numberSockCount = 0;
        private int[] arrElement;
        public SockMerchant()
        {

        }

        public void getUserInput()
        {
            Console.Write("Please Enter the Socks Count : ");
            _numberSockCount = Int32.Parse(Console.ReadLine().ToString());
            Console.Write("Printed : " + _numberSockCount);
            arrElement = new int[_numberSockCount];
            for (int i = 0; i < _numberSockCount; i++)
            {
                Console.Write("\nEnter Number : ");
                arrElement[i] = Int32.Parse(Console.ReadLine().ToString());
            }

            for (int i = 0; i < _numberSockCount; i++)
            {
                Console.Write(" "+arrElement[i]);
            }

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            SockMerchant sockMerchant = new SockMerchant();
            sockMerchant.getUserInput();
            Console.ReadLine();

        }
    }
}
